# ChatSecure
This is a secure chat app with AES encryption, Firebase backend, and smart AI replies.